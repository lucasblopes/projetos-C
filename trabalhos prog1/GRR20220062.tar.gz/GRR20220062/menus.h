#ifndef MENU_H
#define MENU_H

#include "tipos.h"

void imprimirLogo();

void imprimirInstrucoes();

void imprimirTelaFinal(struct Game* game);

#endif 